const { randomUUID, randomBytes, scryptSync, timingSafeEqual } = require('crypto');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const schemaPath = path.join(__dirname, 'schema.sql');
const dbFilePath = path.join(__dirname, '..', 'data', 'easy_bill.db');

const ADMIN_USERNAME = 'pxfish';
const ADMIN_PASSWORD_HASH = '2e9d18ec052a633688ace5bb7f97ec90:669cecbbeba2ad4d3d6668baa329999bc924409a5833eac7434cd6ac7ab69c8e1a5537e703313c28dde835cdb89b20531c0ec0c669eec3672b4ffc0a470925c6';

fs.mkdirSync(path.dirname(dbFilePath), { recursive: true });

const db = new Database(dbFilePath);
db.pragma('journal_mode = WAL');

db.exec(fs.readFileSync(schemaPath, 'utf-8'));

function hasColumn(tableName, columnName) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  return columns.some((column) => column.name === columnName);
}

function ensureSchemaCompatibility() {
  if (!hasColumn('users', 'password_hash')) {
    db.exec('ALTER TABLE users ADD COLUMN password_hash TEXT');
  }
  if (!hasColumn('users', 'role')) {
    db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'");
  }
  if (!hasColumn('users', 'is_disabled')) {
    db.exec('ALTER TABLE users ADD COLUMN is_disabled INTEGER NOT NULL DEFAULT 0');
  }
  if (!hasColumn('users', 'last_login_at')) {
    db.exec('ALTER TABLE users ADD COLUMN last_login_at TEXT');
  }
  if (!hasColumn('redeem_keys', 'created_by')) {
    db.exec('ALTER TABLE redeem_keys ADD COLUMN created_by INTEGER');
  }
  if (!hasColumn('orders', 'order_group_id')) {
    db.exec('ALTER TABLE orders ADD COLUMN order_group_id TEXT');
  }
  if (!hasColumn('orders', 'order_total_amount')) {
    db.exec('ALTER TABLE orders ADD COLUMN order_total_amount REAL');
  }

  db.exec(`
    CREATE TABLE IF NOT EXISTS api_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      method TEXT NOT NULL,
      path TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE INDEX IF NOT EXISTS idx_api_logs_user_created
    ON api_logs(user_id, created_at DESC);
  `);
}

function hashPassword(password) {
  const salt = randomBytes(16).toString('hex');
  const derivedKey = scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derivedKey}`;
}

function verifyPassword(password, storedHash) {
  const [salt, original] = String(storedHash || '').split(':');
  if (!salt || !original) {
    return false;
  }

  const originalBuffer = Buffer.from(original, 'hex');
  const incomingBuffer = Buffer.from(scryptSync(password, salt, 64).toString('hex'), 'hex');

  if (originalBuffer.length !== incomingBuffer.length) {
    return false;
  }

  return timingSafeEqual(originalBuffer, incomingBuffer);
}

function seedInitialData() {
  const now = new Date().toISOString();
  const seedRedeemKeys = [
    { keyCode: 'VIP30-2026', days: 30 },
    { keyCode: 'VIP90-2026', days: 90 },
    { keyCode: 'VIP365-2026', days: 365 }
  ];

  const insertRedeemKeyStmt = db.prepare(`
    INSERT INTO redeem_keys (key_code, days, created_at)
    VALUES (@keyCode, @days, @createdAt)
    ON CONFLICT(key_code) DO NOTHING
  `);

  for (const item of seedRedeemKeys) {
    insertRedeemKeyStmt.run({
      keyCode: item.keyCode,
      days: item.days,
      createdAt: now
    });
  }

  const adminToken = createToken();

  db.prepare(`
    INSERT INTO users (username, password_hash, token, role, is_disabled, membership_expires_at, last_login_at, created_at)
    VALUES (@username, @passwordHash, @token, 'admin', 0, NULL, @now, @now)
    ON CONFLICT(username) DO UPDATE SET
      role = 'admin',
      is_disabled = 0,
      password_hash = excluded.password_hash
  `).run({
    username: ADMIN_USERNAME,
    passwordHash: ADMIN_PASSWORD_HASH,
    token: adminToken,
    now
  });
}

function createToken() {
  return `tk_${randomUUID().replace(/-/g, '')}`;
}

ensureSchemaCompatibility();
seedInitialData();

module.exports = {
  db,
  createToken,
  hashPassword,
  verifyPassword
};
