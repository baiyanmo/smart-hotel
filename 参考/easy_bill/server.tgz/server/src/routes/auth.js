const express = require('express');
const { db, createToken, hashPassword, verifyPassword } = require('../db');
const { authMiddleware } = require('../middleware/auth');
const { auditMiddleware } = require('../middleware/audit');

const router = express.Router();

router.post('/login', (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '').trim();

  if (!username || !password) {
    return res.status(400).json({ message: '用户名和密码不能为空' });
  }

  const found = db.prepare(`
    SELECT id, username, password_hash, token, role, is_disabled, membership_expires_at
    FROM users
    WHERE username = ?
  `).get(username);

  if (!found) {
    const token = createToken();
    const createdAt = new Date().toISOString();
    const passwordHash = hashPassword(password);

    db.prepare(
      'INSERT INTO users (username, password_hash, token, role, is_disabled, membership_expires_at, last_login_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(username, passwordHash, token, 'user', 0, null, createdAt, createdAt);

    return res.json({
      token,
      username,
      role: 'user',
      membershipExpiresAt: null
    });
  }

  if (found.is_disabled) {
    return res.status(403).json({ message: '账号已被禁用，请联系管理员' });
  }

  if (!found.password_hash) {
    const migratedHash = hashPassword(password);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(migratedHash, found.id);
  } else if (!verifyPassword(password, found.password_hash)) {
    return res.status(401).json({ message: '用户名或密码错误' });
  }

  const token = createToken();
  const now = new Date().toISOString();
  db.prepare('UPDATE users SET token = ?, last_login_at = ? WHERE id = ?').run(token, now, found.id);

  return res.json({
    token,
    username: found.username,
    role: found.role,
    membershipExpiresAt: found.membership_expires_at
  });
});

router.post('/change-password', authMiddleware, auditMiddleware, (req, res) => {
  const oldPassword = String(req.body?.oldPassword || '').trim();
  const newPassword = String(req.body?.newPassword || '').trim();

  if (!oldPassword || !newPassword) {
    return res.status(400).json({ message: '旧密码和新密码不能为空' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ message: '密码长度不能少于 6 位' });
  }

  const currentUser = db.prepare('SELECT id, password_hash FROM users WHERE id = ?').get(req.user.id);
  if (!currentUser) {
    return res.status(404).json({ message: '用户不存在' });
  }

  if (!currentUser.password_hash || !verifyPassword(oldPassword, currentUser.password_hash)) {
    return res.status(401).json({ message: '旧密码错误' });
  }

  const passwordHash = hashPassword(newPassword);
  db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(passwordHash, req.user.id);

  return res.json({ message: '密码修改成功' });
});

router.get('/me', authMiddleware, auditMiddleware, (req, res) => {
  return res.json({
    username: req.user.username,
    role: req.user.role,
    membershipExpiresAt: req.user.membership_expires_at
  });
});

module.exports = router;
