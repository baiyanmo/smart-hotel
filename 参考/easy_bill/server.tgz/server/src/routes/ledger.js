const express = require('express');
const XLSX = require('xlsx');
const { db } = require('../db');
const { authMiddleware } = require('../middleware/auth');
const { auditMiddleware } = require('../middleware/audit');

const router = express.Router();

function parseDateRange(startDate, endDate) {
  const start = String(startDate || '').trim();
  const end = String(endDate || '').trim();

  if (start && !/^\d{4}-\d{2}-\d{2}$/.test(start)) {
    throw new Error('startDate 格式错误，需 YYYY-MM-DD');
  }
  if (end && !/^\d{4}-\d{2}-\d{2}$/.test(end)) {
    throw new Error('endDate 格式错误，需 YYYY-MM-DD');
  }
  if (start && end && start > end) {
    throw new Error('开始日期不能晚于结束日期');
  }

  return {
    startAt: start ? `${start}T00:00:00.000Z` : '',
    endAt: end ? `${end}T23:59:59.999Z` : ''
  };
}

function queryLedgerRows(userId, customerName, startDate, endDate) {
  const { startAt, endAt } = parseDateRange(startDate, endDate);
  const conditions = ['user_id = ?', 'customer_name = ?'];
  const params = [userId, customerName];

  if (startAt) {
    conditions.push('created_at >= ?');
    params.push(startAt);
  }
  if (endAt) {
    conditions.push('created_at <= ?');
    params.push(endAt);
  }

  return db.prepare(`
    SELECT id,
           ship_date AS shipDate,
           order_no AS orderNo,
           order_group_id AS orderGroupId,
           product_spec AS productSpec,
           size_count AS sizeCount,
           unit_price AS unitPrice,
           amount,
           order_total_amount AS orderTotalAmount,
           customer_name AS customerName,
           created_at AS createdAt
    FROM orders
    WHERE ${conditions.join(' AND ')}
    ORDER BY created_at DESC, id DESC
  `).all(...params);
}

function groupLedgerRows(rows) {
  const groupedMap = new Map();
  for (const row of rows) {
    const fallbackGroupId = `legacy-${row.orderNo}-${row.createdAt}`;
    const groupId = row.orderGroupId || fallbackGroupId;

    if (!groupedMap.has(groupId)) {
      groupedMap.set(groupId, {
        orderGroupId: groupId,
        shipDate: row.shipDate,
        orderNo: row.orderNo,
        customerName: row.customerName,
        orderTotalAmount: Number(row.orderTotalAmount || 0),
        createdAt: row.createdAt,
        items: []
      });
    }

    groupedMap.get(groupId).items.push({
      id: row.id,
      productSpec: row.productSpec,
      sizeCount: row.sizeCount,
      unitPrice: row.unitPrice,
      amount: row.amount
    });
  }

  return Array.from(groupedMap.values()).map((order) => {
    const computedTotal = Number(order.items.reduce((sum, item) => sum + Number(item.amount || 0), 0).toFixed(2));
    return {
      ...order,
      orderTotalAmount: order.orderTotalAmount > 0 ? order.orderTotalAmount : computedTotal
    };
  });
}

router.get('/customers', authMiddleware, auditMiddleware, (req, res) => {
  const rows = db.prepare(`
    SELECT DISTINCT customer_name AS customerName
    FROM orders
    WHERE user_id = ?
    ORDER BY customer_name COLLATE NOCASE ASC
  `).all(req.user.id);

  res.json({ customers: rows.map((item) => item.customerName) });
});

router.get('/orders', authMiddleware, auditMiddleware, (req, res) => {
  try {
    const customerName = String(req.query.customerName || '').trim();
    const startDate = String(req.query.startDate || '').trim();
    const endDate = String(req.query.endDate || '').trim();

    if (!customerName) {
      return res.status(400).json({ message: 'customerName 不能为空' });
    }

    const rows = queryLedgerRows(req.user.id, customerName, startDate, endDate);
    const orders = groupLedgerRows(rows);

    return res.json({ orders });
  } catch (error) {
    return res.status(400).json({ message: error.message || '参数错误' });
  }
});

router.get('/export', authMiddleware, auditMiddleware, (req, res) => {
  try {
    const customerName = String(req.query.customerName || '').trim();
    const startDate = String(req.query.startDate || '').trim();
    const endDate = String(req.query.endDate || '').trim();

    if (!customerName) {
      return res.status(400).json({ message: 'customerName 不能为空' });
    }

    const rows = queryLedgerRows(req.user.id, customerName, startDate, endDate);
    const orders = groupLedgerRows(rows);

    const exportRows = [];
    for (const order of orders) {
      for (const item of order.items) {
        exportRows.push({
          开单时间: order.createdAt,
          发货日期: order.shipDate,
          单号: order.orderNo,
          客户: order.customerName,
          品名规格: item.productSpec,
          尺数: item.sizeCount,
          单价: item.unitPrice,
          品名金额: item.amount,
          整单总金额: order.orderTotalAmount
        });
      }
    }

    const worksheet = XLSX.utils.json_to_sheet(exportRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, '台账');
    const buffer = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    const filename = `ledger-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}.xlsx`;
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

    return res.send(buffer);
  } catch (error) {
    return res.status(400).json({ message: error.message || '导出失败' });
  }
});

module.exports = router;
