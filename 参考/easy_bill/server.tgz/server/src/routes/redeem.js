const express = require('express');
const { db } = require('../db');
const { authMiddleware } = require('../middleware/auth');
const { auditMiddleware } = require('../middleware/audit');
const { addDays } = require('../utils/date');

const router = express.Router();

router.post('/', authMiddleware, auditMiddleware, (req, res) => {
  const keyCode = String(req.body?.keyCode || '').trim();
  if (!keyCode) {
    return res.status(400).json({ message: '请输入兑换密钥' });
  }

  const keyRow = db.prepare('SELECT id, key_code, days, is_used FROM redeem_keys WHERE key_code = ?').get(keyCode);
  if (!keyRow) {
    return res.status(404).json({ message: '兑换密钥不存在' });
  }

  if (keyRow.is_used) {
    return res.status(400).json({ message: '该兑换密钥已被使用' });
  }

  const nextExpiresAt = addDays(req.user.membership_expires_at, keyRow.days);
  const now = new Date().toISOString();

  const txn = db.transaction(() => {
    db.prepare('UPDATE users SET membership_expires_at = ? WHERE id = ?').run(nextExpiresAt, req.user.id);
    db.prepare('UPDATE redeem_keys SET is_used = 1, used_by = ?, used_at = ? WHERE id = ?').run(req.user.id, now, keyRow.id);
  });

  txn();

  return res.json({
    membershipExpiresAt: nextExpiresAt,
    message: `兑换成功，已延长 ${keyRow.days} 天`
  });
});

module.exports = router;
