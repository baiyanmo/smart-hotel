const express = require('express');
const { randomUUID } = require('crypto');
const { db } = require('../db');
const { authMiddleware } = require('../middleware/auth');
const { auditMiddleware } = require('../middleware/audit');

const router = express.Router();

function toPositiveNumber(value, fieldName) {
  const number = Number(value);
  if (!Number.isFinite(number) || number < 0) {
    throw new Error(`${fieldName} 必须是有效数字`);
  }
  return number;
}

router.post('/', authMiddleware, auditMiddleware, (req, res) => {
  try {
    const shipDate = String(req.body?.shipDate || '').trim();
    const orderNo = String(req.body?.orderNo || '').trim();
    const customerName = String(req.body?.customerName || '').trim();
    const items = Array.isArray(req.body?.items) ? req.body.items : [];

    if (!shipDate || !orderNo || !customerName || items.length === 0) {
      return res.status(400).json({ message: '请填写完整必填字段' });
    }

    const normalizedItems = items.map((item, index) => {
      const productSpec = String(item?.productSpec || '').trim();
      if (!productSpec) {
        throw new Error(`第 ${index + 1} 行品名规格不能为空`);
      }

      const sizeCount = toPositiveNumber(item?.sizeCount, `第 ${index + 1} 行尺数`);
      const unitPrice = toPositiveNumber(item?.unitPrice, `第 ${index + 1} 行单价`);
      const amount = toPositiveNumber(item?.amount, `第 ${index + 1} 行金额`);

      return {
        productSpec,
        sizeCount,
        unitPrice,
        amount
      };
    });

    const orderTotalAmount = Number(
      normalizedItems.reduce((sum, item) => sum + item.amount, 0).toFixed(2)
    );

    const createdAt = new Date().toISOString();
    const orderGroupId = randomUUID();

    const insertStmt = db.prepare(`
      INSERT INTO orders (
        user_id,
        ship_date,
        order_no,
        order_group_id,
        product_spec,
        size_count,
        unit_price,
        amount,
        order_total_amount,
        customer_name,
        created_at
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const txn = db.transaction(() => {
      for (const item of normalizedItems) {
        insertStmt.run(
          req.user.id,
          shipDate,
          orderNo,
          orderGroupId,
          item.productSpec,
          item.sizeCount,
          item.unitPrice,
          item.amount,
          orderTotalAmount,
          customerName,
          createdAt
        );
      }
    });

    txn();

    return res.status(201).json({
      message: '开单成功',
      orderGroupId,
      itemCount: normalizedItems.length,
      orderTotalAmount
    });
  } catch (error) {
    return res.status(400).json({ message: error.message || '参数错误' });
  }
});

module.exports = router;
