const express = require('express');
const { randomUUID } = require('crypto');
const { db, createToken, hashPassword } = require('../db');
const { authMiddleware } = require('../middleware/auth');
const { adminMiddleware } = require('../middleware/admin');
const { auditMiddleware } = require('../middleware/audit');

const router = express.Router();

router.use(authMiddleware, adminMiddleware, auditMiddleware);

router.post('/users', (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '').trim();

  if (!username || !password) {
    return res.status(400).json({ message: '用户名和密码不能为空' });
  }

  if (password.length < 6) {
    return res.status(400).json({ message: '密码长度不能少于 6 位' });
  }

  const exists = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (exists) {
    return res.status(409).json({ message: '用户名已存在' });
  }

  const now = new Date().toISOString();
  const token = createToken();
  const passwordHash = hashPassword(password);

  db.prepare(
    'INSERT INTO users (username, password_hash, token, role, is_disabled, membership_expires_at, last_login_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).run(username, passwordHash, token, 'user', 0, null, null, now);

  return res.status(201).json({ message: '账号创建成功' });
});

router.get('/users', (req, res) => {
  const rows = db.prepare(`
    SELECT u.id,
           u.username,
           u.role,
           u.is_disabled AS isDisabled,
           u.membership_expires_at AS membershipExpiresAt,
           u.last_login_at AS lastLoginAt,
           COUNT(l.id) AS apiCallCount
    FROM users u
    LEFT JOIN api_logs l ON l.user_id = u.id
    GROUP BY u.id
    ORDER BY u.role DESC, u.created_at ASC
  `).all();

  res.json({ users: rows });
});

router.post('/users/:id/reset-password', (req, res) => {
  const userId = Number(req.params.id);
  const newPassword = String(req.body?.newPassword || '').trim();

  if (!userId || !newPassword) {
    return res.status(400).json({ message: '参数不完整' });
  }

  if (newPassword.length < 6) {
    return res.status(400).json({ message: '密码长度不能少于 6 位' });
  }

  const target = db.prepare('SELECT id, role FROM users WHERE id = ?').get(userId);
  if (!target) {
    return res.status(404).json({ message: '用户不存在' });
  }

  if (target.role !== 'user') {
    return res.status(400).json({ message: '仅支持重置普通用户密码' });
  }

  const passwordHash = hashPassword(newPassword);
  const token = createToken();
  db.prepare('UPDATE users SET password_hash = ?, token = ? WHERE id = ?').run(passwordHash, token, userId);

  return res.json({ message: '密码已重置' });
});

router.post('/users/:id/membership', (req, res) => {
  const userId = Number(req.params.id);
  const membershipExpiresAt = String(req.body?.membershipExpiresAt || '').trim();

  if (!userId || !membershipExpiresAt) {
    return res.status(400).json({ message: '参数不完整' });
  }

  const user = db.prepare('SELECT id, role FROM users WHERE id = ?').get(userId);
  if (!user) {
    return res.status(404).json({ message: '用户不存在' });
  }

  db.prepare('UPDATE users SET membership_expires_at = ? WHERE id = ?').run(membershipExpiresAt, userId);
  return res.json({ message: '会员到期时间已更新' });
});

router.post('/users/:id/disable', (req, res) => {
  const userId = Number(req.params.id);
  const isDisabled = Number(req.body?.isDisabled ? 1 : 0);

  if (!userId) {
    return res.status(400).json({ message: '用户参数错误' });
  }

  const user = db.prepare('SELECT id, role FROM users WHERE id = ?').get(userId);
  if (!user) {
    return res.status(404).json({ message: '用户不存在' });
  }

  if (user.role === 'admin') {
    return res.status(400).json({ message: '管理员账号不允许禁用' });
  }

  db.prepare('UPDATE users SET is_disabled = ? WHERE id = ?').run(isDisabled, userId);
  return res.json({ message: isDisabled ? '已禁用用户' : '已启用用户' });
});

router.delete('/users/:id', (req, res) => {
  const userId = Number(req.params.id);
  if (!userId) {
    return res.status(400).json({ message: '用户参数错误' });
  }

  if (userId === req.user.id) {
    return res.status(400).json({ message: '不能删除当前登录管理员' });
  }

  const user = db.prepare('SELECT id, role FROM users WHERE id = ?').get(userId);
  if (!user) {
    return res.status(404).json({ message: '用户不存在' });
  }

  if (user.role === 'admin') {
    return res.status(400).json({ message: '管理员账号不允许删除' });
  }

  const txn = db.transaction(() => {
    db.prepare('DELETE FROM orders WHERE user_id = ?').run(userId);
    db.prepare('DELETE FROM api_logs WHERE user_id = ?').run(userId);
    db.prepare('UPDATE redeem_keys SET used_by = NULL WHERE used_by = ?').run(userId);
    db.prepare('DELETE FROM users WHERE id = ?').run(userId);
  });

  txn();
  return res.json({ message: '用户及相关数据已删除' });
});

router.post('/redeem-keys', (req, res) => {
  const days = Number(req.body?.days);
  const count = Number(req.body?.count || 1);

  if (!Number.isInteger(days) || days <= 0 || !Number.isInteger(count) || count <= 0 || count > 100) {
    return res.status(400).json({ message: 'days/count 参数不合法' });
  }

  const createdAt = new Date().toISOString();
  const insertStmt = db.prepare(
    'INSERT INTO redeem_keys (key_code, days, is_used, created_by, created_at) VALUES (?, ?, 0, ?, ?)'
  );

  const keys = [];
  const txn = db.transaction(() => {
    for (let i = 0; i < count; i += 1) {
      const keyCode = `VIP-${days}D-${randomUUID().slice(0, 8).toUpperCase()}`;
      insertStmt.run(keyCode, days, req.user.id, createdAt);
      keys.push(keyCode);
    }
  });

  txn();

  return res.status(201).json({
    days,
    count,
    keys
  });
});

module.exports = router;
