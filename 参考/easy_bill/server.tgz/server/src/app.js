const express = require('express');
const cors = require('cors');

require('./db');

const authRoutes = require('./routes/auth');
const orderRoutes = require('./routes/orders');
const ledgerRoutes = require('./routes/ledger');
const redeemRoutes = require('./routes/redeem');
const adminRoutes = require('./routes/admin');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => {
  res.json({ ok: true });
});

app.use('/api/auth', authRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/ledger', ledgerRoutes);
app.use('/api/redeem', redeemRoutes);
app.use('/api/admin', adminRoutes);

app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ message: '服务器内部错误' });
});

app.listen(PORT, () => {
  console.log(`Easy Bill server running on http://localhost:${PORT}`);
});
