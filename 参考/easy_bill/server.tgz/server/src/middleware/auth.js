const { db } = require('../db');

function authMiddleware(req, res, next) {
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : '';

  if (!token) {
    return res.status(401).json({ message: '未登录或 token 缺失' });
  }

  const user = db.prepare(
    'SELECT id, username, role, is_disabled, membership_expires_at, token FROM users WHERE token = ?'
  ).get(token);

  if (!user) {
    return res.status(401).json({ message: 'token 无效，请重新登录' });
  }

  if (user.is_disabled) {
    return res.status(403).json({ message: '账号已被禁用，请联系管理员' });
  }

  req.user = user;
  return next();
}

module.exports = {
  authMiddleware
};
