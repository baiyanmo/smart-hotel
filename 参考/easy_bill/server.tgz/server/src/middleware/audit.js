const { db } = require('../db');

function auditMiddleware(req, res, next) {
  if (!req.user?.id) {
    return next();
  }

  const now = new Date().toISOString();
  db.prepare('INSERT INTO api_logs (user_id, method, path, created_at) VALUES (?, ?, ?, ?)')
    .run(req.user.id, req.method, req.path, now);

  return next();
}

module.exports = {
  auditMiddleware
};
