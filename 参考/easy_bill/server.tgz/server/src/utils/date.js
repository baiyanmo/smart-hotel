function addDays(baseDateString, days) {
  const base = baseDateString ? new Date(baseDateString) : new Date();
  const validBase = Number.isNaN(base.getTime()) ? new Date() : base;

  const now = new Date();
  const start = validBase > now ? validBase : now;
  const next = new Date(start);
  next.setDate(next.getDate() + days);
  return next.toISOString();
}

module.exports = {
  addDays
};
